/*
 * dtaea.c:
 *  This file contains the main procedures of the standard DTAEA.
 *  Please note that this version is a beta version
 *
 *
 * Authors:
 *  Renzhi Chen <rxc332@cs.bham.ac.uk>
 *  Ke Li <k.li@exeter.ac.uk>
 *
 * Institution:
 *  Computational Optimization and Data Analytics (CODA) Group @ University of Exeter
 *
 * Copyright (c) 2017 Renzhi Chen, Ke Li
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

# include "../header/metaheuristics.h"
#include "../header/global.h"

#define  DEBUG 0
#define  PRINT_GAP 5
int occupation=-1;
int max_density;
int *CA_density, * CA_location,*DA_density, * DA_location;;
int pool_count;

void print_CA_list(list* l,population_real *pop)
{
    int c = 0;
    printf("---------CA-------------\n");
    list * temp = l->child;
    if(temp==NULL)
        printf("NULL\n");
    else
        do{
            printf("[%d]%d(%d,%d,%.3lf)\n",c++,temp->index,pop->ind[temp->index].rank,CA_location[temp->index],pop->ind[temp->index].fitness);
            temp = temp->child;
        }while(temp!=NULL);
    printf("------------------------\n");

}

void print_DA_list(list* l,population_real *pop)
{
    int c = 0;
    printf("---------DA-------------\n");
    list * temp = l->child;
    if(temp==NULL)
        printf("NULL\n");
    else
        do{
            printf("[%d]%d(%d,%d,%.3lf)\n",c++,temp->index,pop->ind[temp->index].rank,DA_location[temp->index],pop->ind[temp->index].fitness);
            temp = temp->child;
        }while(temp!=NULL);
    printf("------------------------\n");

}

double distance(double * p, double* vector) {
    double d1 = 0, d2 = 0;
    double nl = 0;
    int i;
    for ( i = 0; i < number_objective; i++) {
        d1 += (p[i] - ideal_point[i]) * vector[i];
        nl += vector[i]*vector[i];
    }
    nl = sqrt(nl);
    d1 = fabs(d1) / nl;

    for (i = 0; i < number_objective; i++) {
        d2 += ((p[i] - ideal_point[i]) - d1 * (vector[i] / nl))*((p[i] - ideal_point[i]) - d1 * (vector[i] / nl));
    }
    d2 = sqrt(d2);
    return d2;
}

void taea_association(population_real *mixed_pop,list * pool,int *density,int *location)
{
    int i,j;
    max_density = 0;
    double maxFun,minFun;
    occupation = 0;

    for(i =0; i<number_weight;i++)
        density[i] = 0;

    list * temp = pool->child;
    do
    {
        i = temp->index;
        minFun = distance(mixed_pop->ind[i].obj,lambda[0]);
        int minId = 0;

        for(j=1;j<number_weight;j++)
        {
            double diff = distance(mixed_pop->ind[i].obj,lambda[j]);
            if(diff < minFun)
            {
                minFun = diff;
                minId = j;
            }
        }
        if(density[minId] == 0)
            occupation ++;
        density[minId] ++;
        location[i] = minId;
        if(density[minId]>max_density)
            max_density = density[minId];
        maxFun = -1;
        for(j=0;j<number_objective;j++)
        {
            double diff = fabs(mixed_pop->ind[i].obj[j]-ideal_point[j]);
            double feval;
            if(lambda[minId][j] == 0)
            {    feval = diff / 0.0001;
            }
            else
            {
                feval = diff / lambda[minId][j];
            }
            if (feval > maxFun) {
                maxFun = feval;
            }
        }
        mixed_pop->ind[i].fitness = maxFun;
        temp = temp->child;
    }while(temp!=NULL);
}

void taea_assign_rank (population_real *pop, int size,int request, list * selected)
{
    int i, j;
    int flag, end;
    int rank = 0;
    int cur_size = 0;

    pool_count = 0;

    list *pool;
    list *elite;
    list *temp1, *temp2;

    pool  = (list *) malloc (sizeof(list));
    elite = (list *) malloc (sizeof(list));
    pool->index   = -1;
    pool->parent  = NULL;
    pool->child   = NULL;
    elite->index  = -1;
    elite->parent = NULL;
    elite->child  = NULL;

    temp1 = pool;
    for (i = 0; i < size; i++)
    {
        insert (temp1,i);
        temp1 = temp1->child;
    }
    i = 0;
    do
    {
        temp1 = pool->child;
        insert (elite, temp1->index);
        temp2 = elite->child;
        temp1 = del (temp1);
        temp1 = temp1->child;
        do
        {
            temp2 = elite->child;
            if (temp1 == NULL)
                break;

            do
            {
                end  = 0;
                flag = check_dominance (&(pop->ind[temp1->index]), &(pop->ind[temp2->index]));
                if (flag == 1)
                {
                    insert (pool, temp2->index);
                    temp2 = del (temp2);
                    temp2 = temp2->child;
                }
                if (flag == 0)
                {
                    temp2 = temp2->child;
                }
                if (flag == -1)
                {
                    end = 1;
                }
            }
            while (end != 1 && temp2 != NULL);
            if (flag == 0 || flag == 1)
            {
                insert (elite, temp1->index);
                temp1 = del (temp1);
            }
            temp1 = temp1->child;
        }
        while (temp1 != NULL);

        // copy each level into candidate
        if (cur_size < request)
        {

            temp2    = elite->child;

            do
            {
                insert(selected,temp2->index);
                pool_count ++;
                pop->ind[temp2->index].rank = rank;
                cur_size++;
                temp2 = temp2->child;
            }
            while (temp2 != NULL);
            rank++;
        }

        temp2 = elite->child;
        do
        {
            temp2 = del (temp2);
            temp2 = temp2->child;
        }
        while (elite->child !=NULL);
    }
    while (cur_size < request);

    // garbage collection
    while (pool != NULL)
    {
        temp1 = pool;
        pool  = pool->child;
        free (temp1);
    }
    while (elite != NULL)
    {
        temp1 = elite;
        elite = elite->child;
        free (temp1);
    }
}

int get_non_dominated (population_real *pop, list * pool)
{
    int i, j;
    int flag, end;

    list *elite;
    list *temp1, *temp2;

    elite = (list *) malloc (sizeof(list));

    elite->index  = -1;
    elite->parent = NULL;
    elite->child  = NULL;


    i = 0;


    temp1 = pool->child;
    insert (elite, temp1->index);
    temp2 = elite->child;
    temp1 = del (temp1);
    temp1 = temp1->child;
    do
    {
        temp2 = elite->child;
        if (temp1 == NULL)
            break;

        do
        {
            end  = 0;
            flag = check_dominance (&(pop->ind[temp1->index]), &(pop->ind[temp2->index]));
            if (flag == 1)
            {
                insert (pool, temp2->index);
                temp2 = del (temp2);
                temp2 = temp2->child;
            }
            if (flag == 0)
            {
                temp2 = temp2->child;
            }
            if (flag == -1)
            {
                end = 1;
            }
        }
        while (end != 1 && temp2 != NULL);
        if (flag == 0 || flag == 1)
        {
            insert (elite, temp1->index);
            temp1 = del (temp1);
        }
        temp1 = temp1->child;
    }
    while (temp1 != NULL);

        // copy each level into candidate

    temp2    = elite->child;

    double minFun = pop->ind[temp2->index].fitness;
    int minId = temp2->index;
     while(temp2->child!=NULL) {
        temp2 = temp2->child;
        if(minFun < pop->ind[temp2->index].fitness) {
             minFun = pop->ind[temp2->index].fitness;
             minId = temp2->index;
        }
    }

    while (elite != NULL)
    {
        temp1 = elite;
        elite = elite->child;
        free (temp1);
    }
    return minId;
}
void CA_selection(population_real *mixed_pop, population_real * CA)
{
    int i,j;
    list * pool,*ind,*temp;
    pool  = (list *) malloc (sizeof(list));
    pool->index   = -1;
    pool->parent  = NULL;
    pool->child   = NULL;   // empty pool

    taea_assign_rank(mixed_pop,popsize * 2,popsize,pool);    // get pool from dominate

    taea_association(mixed_pop,pool,CA_density,CA_location);    // associate pool

    while(pool_count>popsize)
    {
        double maxFun = -1;
        int maxId = -1;
        for(i = 0;i < number_weight;i++)
        {
            if(CA_density[i] == max_density)
            {
                temp = pool->child;
                do{
                    j = temp->index;

                    if(CA_location[j]==i&&mixed_pop->ind[j].fitness>maxFun)
                    {
                        maxId = j;
                        maxFun = mixed_pop->ind[j].fitness;
                        ind = temp;
                    }
                    temp = temp->child;
                }while(temp!=NULL);
            }
        }
        if(maxId!=-1){

            pool_count --;
            del(ind);
            CA_density[CA_location[maxId]]--;
        }
        else
        {
            max_density --;
        }

    }
    temp = pool->child;
    j = 0;
    do{
        i = temp->index;
        copy_ind(&mixed_pop->ind[i],&CA->ind[j]);
        j++;
        temp = temp->child;
    }while(temp!=NULL);

    while (pool != NULL)
    {
        temp = pool;
        pool  = pool->child;
        free (temp);
    }


}
void DA_selection(population_real *mixed_pop, population_real * CA,population_real * DA)
{
    list * pool,*ind,*temp;
    int c=0;
    int i,j,k;
    double maxFun;
    int maxId;

    pool  = (list *) malloc (sizeof(list));
    pool->index   = -1;
    pool->parent  = NULL;
    pool->child   = NULL;   // empty pool

    ind  = (list *) malloc (sizeof(list));
    ind->index   = -1;
    ind->parent  = NULL;
    ind->child   = NULL;   // empty pool


    for( i=0;i<popsize;i++)
        insert(pool,i);
    taea_association(CA,pool,CA_density,CA_location);

    while (pool->child != NULL)
    {
        temp = pool;
        pool  = pool->child;
        free (temp);
    }
    pool->index   = -1;
    pool->parent  = NULL;
    pool->child   = NULL;   // empty pool
    for( i=0;i<2*popsize;i++)
        insert(pool,i);
    taea_association(mixed_pop,pool,DA_density,DA_location);

    i = 0;  //
    while(c<popsize)
    {
        i++;
        for(j=0;j<number_weight;j++)
        {
            if(CA_density[j]>i)
                continue;
            else if(DA_density[j]>0)    // need to
            {

                temp = pool->child;
                do{
                    k = temp->index;
                    if(DA_location[k]==j)
                    {
                        insert(ind,k);
                        //printf("(%d)insert %d\n",i,k);
                    }
                    temp = temp->child;
                }while(temp!=NULL);
                k = get_non_dominated(mixed_pop,ind);
                while(ind->child!=NULL)
                {
                    ind = ind->child;
                    free(ind->parent);
                }
                ind->index =-1;
                ind->parent =NULL;
                ind->child = NULL;

                //printf("%d select %d(%lf)\n",c,k,mixed_pop->ind[k].fitness);
                temp = pool->child;
                do{
                    int k2 = temp->index;
                    if(k==k2) {
                        del(temp);
                        break;
                    }
                    temp=temp->child;

                }while(temp!=NULL);
                CA_density[DA_location[k]]++;
                DA_density[DA_location[k]]--;
                copy_ind(&mixed_pop->ind[k],&DA->ind[c]);
                c++;
                if(c==popsize)
                    break;
            }
        }

    }
}

void free_weight()
{
    int i;
    for (i = 0; i < number_weight; i++)
        free(lambda[i]);
    free(lambda);
}


void crossover_taea(population_real *CA, population_real *DA, population_real *offspring_pop)
{
    int i, temp, rand;
    int *a1, *a2;
    individual_real *parent1, *parent2;

    a1 = (int *) malloc (popsize * sizeof(int));
    a2 = (int *) malloc (popsize * sizeof(int));
    for (i = 0; i < popsize; i++)
        a1[i] = a2[i] = i;

    for (i = 0; i < popsize; i++)
    {
        rand     = rnd (i, popsize - 1);
        temp     = a1[rand];
        a1[rand] = a1[i];
        a1[i]    = temp;
        rand     = rnd (i, popsize - 1);
        temp     = a2[rand];
        a2[rand] = a2[i];
        a2[i]    = temp;
    }
    for (i = 0; i < popsize; i += 2)
    {
        parent1 = tournament (&CA->ind[a1[i]], &CA->ind[a1[i + 1]]);

        if(occupation!=-1&&rnd(0,number_weight)>occupation)
            parent2 = tournament (&DA->ind[a2[i]], &DA->ind[a1[i + 1]]);
        else
            parent2 = tournament (&CA->ind[a2[i]], &CA->ind[a1[i + 1]]);

        sbx_crossover (parent1, parent2, &offspring_pop->ind[i], &offspring_pop->ind[i + 1]);
    }
    free (a1);
    free (a2);
}



void copy_ind_var (individual_real *ind1, individual_real *ind2)
{

    // this function copy the var from ind1 to ind2
    int i;

    ind2->rank    = ind1->rank;
    ind2->fitness = ind1->fitness;
    ind2->cv      = ind1->cv ;
    if (number_variable != 0)
        for (i = 0; i < number_variable; i++)
            ind2->xreal[i] = ind1->xreal[i];

    return;
}


void DTAEA (population_real *pop, population_real *offspring_pop, population_real *mixed_pop)
{
    int i, j, k;
    int generation;

    int changed = 0;  //  flag for change
    int pre_number_objective = number_objective;

    int max_rank;

    population_real *CA;
    CA = pop;
    population_real *DA;
    DA    = (population_real *) malloc (sizeof(population_real));
    allocate_memory_pop (DA, popsize);

    generation       = 1;
    evaluation_count = 0;
    printf ("|\tThe %d run\t|\t1%%\t|", run_index);

    // initialization process
    initialize_uniform_weight ();
    CA_density = malloc(sizeof(int) * number_weight);
    CA_location = malloc(sizeof(int) * 2 * popsize);
    DA_density = malloc(sizeof(int) * number_weight);
    DA_location = malloc(sizeof(int) * 2 * popsize);

    print_error (number_weight != popsize, 1, "Number of weight vectors must be equal to the population size!");

    initialize_population_real (CA);
    evaluate_population (CA);
    initialize_idealpoint (CA);
    for(i=0;i<popsize;i++)
        copy_ind(&CA->ind[i],&DA->ind[i]);
    track_evolution (pop, generation, 0);

    while (evaluation_count < max_evaluation)
    {
        //printf("g:%d\n",generation);
        print_progress();

        crossover_taea (CA, DA, offspring_pop);
        mutation_real (offspring_pop);
        evaluate_population (offspring_pop);

        pre_number_objective = number_objective;
        if(problem_update(generation))
        {
            changed = 1;

            if(pre_number_objective<number_objective)// num. of obj increase
            {

                for ( k = 0; k < popsize; k++) {
                    copy_ind_var(&CA->ind[k],&offspring_pop->ind[k]); // save CA in offspring

                }
                if(DEBUG){printf("CA to off\n");}
                // reset space for objective array
                deallocate_memory_pop(DA,popsize);
                allocate_memory_pop(DA,popsize);
                deallocate_memory_pop(CA,popsize);
                allocate_memory_pop(CA,popsize);

                for ( k = 0; k < popsize; k++) {
                    copy_ind_var(&offspring_pop->ind[k],&CA->ind[k]); // Copy old CA to CA
                }
                if(DEBUG){printf("off to CA\n");}
                // reset space for objective array
                deallocate_memory_pop(offspring_pop,popsize);
                allocate_memory_pop(offspring_pop,popsize);
                deallocate_memory_pop(mixed_pop,2*popsize);
                allocate_memory_pop(mixed_pop,2*popsize);
                //     fill DA with random ind
                initialize_population_real (DA);

                evaluate_population(CA);
                evaluate_population(DA);

                free_weight();
                free(CA_density);
                free(DA_density);
                initialize_uniform_weight ();
                CA_density = malloc(sizeof(int) * number_weight);
                DA_density = malloc(sizeof(int) * number_weight);
            }
            if(pre_number_objective>number_objective)// num. of obj decrease
            {
                free_weight();
                free(CA_density);
                free(DA_density);
                initialize_uniform_weight ();
                CA_density = malloc(sizeof(int) * number_weight);
                DA_density = malloc(sizeof(int) * number_weight);

                for ( k = 0; k < popsize; k++) {
                    copy_ind_var(&CA->ind[k],&offspring_pop->ind[k]); // save CA in offspring
                }
                // reset space for objective array
                deallocate_memory_pop(DA,popsize);
                allocate_memory_pop(DA,popsize);
                deallocate_memory_pop(CA,popsize);
                allocate_memory_pop(CA,popsize);
                deallocate_memory_pop(mixed_pop,2*popsize);
                allocate_memory_pop(mixed_pop,2*popsize);
                for ( k = 0; k < popsize; k++) {
                    copy_ind_var(&offspring_pop->ind[k],&CA->ind[k]); // Copy old CA to CA
                }

                // reset space for objective array
                deallocate_memory_pop(offspring_pop,popsize);
                allocate_memory_pop(offspring_pop,popsize);
                evaluate_population(CA);
                initialize_population_real (DA);

                list * pool  = (list *) malloc (sizeof(list));
                pool->index   = -1;
                pool->parent  = NULL;
                pool->child   = NULL;   // empty pool

                taea_assign_rank(CA,popsize,popsize,pool);

                int CA_cur_size = 0;
                int DA_cur_size = 0;
                list * temp = pool->child;
                while(temp!=NULL)
                {
                    int idx = temp->index;
                    temp = temp->child;
                    // rank = 0 still in CA
                    CA_cur_size ++;
                    if(DEBUG){printf("CA(%d)%d\n",idx,CA->ind[idx].rank);}

                    if(CA->ind[idx].rank!=0)
                    {
                        CA_cur_size--;
                        if(DEBUG){printf("CA(%d) to DA(%d)\n",idx,DA_cur_size);}
                        copy_ind(&CA->ind[idx],&DA->ind[DA_cur_size]);
                        DA_cur_size++;
                    }
                }

                evaluate_population(DA);

                for(k=0;k<popsize;k++) {
                    if (CA->ind[k].rank > 0) {

                        int r = rand() % CA_cur_size;
                        temp = pool->child;
                        while (temp != NULL && r > 0) {
                            r--;
                            temp = temp->child;
                        }
                        if(DEBUG){printf("CA to CA\n");}
                        copy_ind(&CA->ind[temp->index], &CA->ind[k]);
                        mutation_ind(&CA->ind[k]);
                    }
                }

                while (pool != NULL)
                {
                    temp = pool;
                    pool  = pool->child;
                    free (temp);
                }

            }
            if(pre_number_objective==number_objective)
            {

                // no reaction towards this type of dynamic
                // further work can be done here
            }
            changed = 1;
        }
        else if (changed)
        {

            // select CA
            if(DEBUG){printf("CA selection\n");}
            merge (CA, offspring_pop, mixed_pop);
            CA_selection(mixed_pop,CA);


            // select DA
            if(DEBUG){printf("CA selection\n");}
            merge(DA,offspring_pop,mixed_pop);
            DA_selection(mixed_pop,CA,DA);

        }
        else
        {
            merge (CA, offspring_pop, mixed_pop);
            CA_selection(mixed_pop,CA);
            for(i=0;i<popsize;i++)
                copy_ind(&CA->ind[i],&DA->ind[i]);
        }


        char output_file[BUFSIZE_M];
        if(DEBUG&&generation%PRINT_GAP==0) {
            sprintf(output_file, "out/medium_CA_%d.out", generation);
            print_objective(output_file, CA);
            sprintf(output_file, "out/medium_DA_%d.out", generation);
            print_objective(output_file, DA);
        }
        generation++;
        //py_plot(CA,generation,1);
        //py_plot(DA,generation,2);
        track_evolution (pop, generation, evaluation_count >= max_evaluation);
    }

    deallocate_memory_pop(DA,popsize);
    free(CA_density);
    free(DA_density);
    return;
}
